Name: Manaswini Gogineni
cs login: manaswini-09
wisc ID: 908 543 2699
email: mgogineni@wisc.edu
status: everything works

**Source**
1. The GNU Manual - https://www.gnu.org/software/libc/manual/html_node/index.html#SEC_Contents 

For understanding signal handling, job control, understanding the implementation of the basic shell

2. Stackoverflow - To understand the reason behind some of the segmentation faults.

3. Man Pages - To understand most of the libraries and the functions used in the implementation

